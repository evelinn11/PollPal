//
//  New_Survey_PollPalApp.swift
//  New Survey PollPal
//
//  Created by student on 27/11/25.
//

import SwiftUI

@main
struct New_Survey_PollPalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
