//
//  CoreDataManager.swift
//  PollPal
//
//  Created by student on 01/12/25.
//

import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()

    // Persistent container for managing the Core Data stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "Model") // Name must match your .xcdatamodeld file
        container.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Failed to load Core Data stack: \(error)")
            }
        }
        return container
    }()

    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }

    // Save changes to Core Data
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print("Failed to save context: \(error)")
            }
        }
    }
}
