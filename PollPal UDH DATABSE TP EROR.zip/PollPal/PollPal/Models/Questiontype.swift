//
//  Questiontype.swift
//  PollPal
//
//  Created by student on 27/11/25.
//

enum QuestionType: String, Codable, CaseIterable, Identifiable {
    case shortAnswer
    case paragraph
    case multipleChoice
    case checkboxes
    case dropdown
    case linearScale

    var id: String { self.rawValue }
}
