//
//  AnyCodable.swift
//  PollPal
//
//  Created by student on 27/11/25.
//

import Foundation

import Foundation

struct AnyCodable: Codable {
    var value: Any

    init(_ value: Any) { self.value = value }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let str = try? container.decode(String.self) {
            value = str
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let arr = try? container.decode([String].self) {
            value = arr
        } else {
            value = ""
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let str = value as? String {
            try container.encode(str)
        } else if let int = value as? Int {
            try container.encode(int)
        } else if let arr = value as? [String] {
            try container.encode(arr)
        } else {
            try container.encode("")
        }
    }
}
