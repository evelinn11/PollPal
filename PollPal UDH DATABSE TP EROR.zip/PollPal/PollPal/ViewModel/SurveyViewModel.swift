import SwiftUI
import CoreData

class SurveyViewModel: ObservableObject {
    @Published var questions: [Question] = []

    func addQuestion(type: QuestionType) {
        var newQ = QuestionModel(title: "Pertanyaan Baru", type: type)

        switch type {
        case .multipleChoice, .checkboxes, .dropdown:
            newQ.options = ["Option 1", "Option 2"]
        case .linearScale:
            newQ.scaleRange = 1...5
        default: break
        }

        questions.append(newQ)
    }

    func saveSurvey(survey: Survey, context: NSManagedObjectContext) {
        // Buat entity Survey baru
        let surveyEntity = Survey(context: context)
        surveyEntity.id = UUID()
        surveyEntity.title = survey.survey_title
        surveyEntity.desc = survey.survey_description

        // Buat entity Question untuk setiap question di ViewModel
        for q in questions {
            let questionEntity = Question(context: context)
            questionEntity.id = UUID()
            questionEntity.title = q.title
            questionEntity.type = q.type.rawValue
            questionEntity.survey = surveyEntity // relasi ke survey

            // Simpan options jika ada
            if let options = q.options {
                questionEntity.options = options
            }

            // Simpan linearScale jika ada
            if let scale = q.scaleRange {
                questionEntity.scaleMin = Int16(scale.lowerBound)
                questionEntity.scaleMax = Int16(scale.upperBound)
            }
        }

        // Simpan context
        do {
            try context.save()
            print("Survey berhasil disimpan!")
        } catch {
            print("Gagal simpan survey: \(error)")
        }
    }
}
