//
//  Option+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias OptionCoreDataPropertiesSet = NSSet

extension Option {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Option> {
        return NSFetchRequest<Option>(entityName: "Option")
    }

    @NSManaged public var option_id: UUID?
    @NSManaged public var option_text: String?
    @NSManaged public var in_dresponse: DResponse?
    @NSManaged public var in_question: Question?

}

extension Option : Identifiable {

}
