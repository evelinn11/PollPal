//
//  Question+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias QuestionCoreDataPropertiesSet = NSSet

extension Question {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Question> {
        return NSFetchRequest<Question>(entityName: "Question")
    }

    @NSManaged public var question_id: UUID?
    @NSManaged public var question_text: String?
    @NSManaged public var question_type: String?
    @NSManaged public var question_price: Int32
    @NSManaged public var question_img_url: String?
    @NSManaged public var question_status_del: Bool
    @NSManaged public var attribute: NSObject?
    @NSManaged public var attribute1: NSObject?
    @NSManaged public var attribute2: NSObject?
    @NSManaged public var attribute3: NSObject?
    @NSManaged public var attribute4: NSObject?
    @NSManaged public var in_survey: Survey?
    @NSManaged public var has_response: HResponse?
    @NSManaged public var has_option: Option?

}

extension Question : Identifiable {

}
