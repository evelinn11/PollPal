//
//  User+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias UserCoreDataPropertiesSet = NSSet

extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var user_id: UUID?
    @NSManaged public var user_name: String?
    @NSManaged public var user_email: String?
    @NSManaged public var user_password: String?
    @NSManaged public var user_points: Int32
    @NSManaged public var user_header_img: String?
    @NSManaged public var user_profile_img: String?
    @NSManaged public var user_created_at: Date?
    @NSManaged public var user_status_del: Bool
    @NSManaged public var has_survey: Survey?
    @NSManaged public var filled_hresponse: HResponse?
    @NSManaged public var has_transaction: Transaction?

}

extension User : Identifiable {

}
