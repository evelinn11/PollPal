//
//  Survey+CoreDataClass.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData

public typealias SurveyCoreDataClassSet = NSSet

@objc(Survey)
public class Survey: NSManagedObject {

}
