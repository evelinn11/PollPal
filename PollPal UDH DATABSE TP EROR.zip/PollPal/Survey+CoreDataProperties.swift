//
//  Survey+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias SurveyCoreDataPropertiesSet = NSSet

extension Survey {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Survey> {
        return NSFetchRequest<Survey>(entityName: "Survey")
    }

    @NSManaged public var survey_id: UUID?
    @NSManaged public var survey_title: String?
    @NSManaged public var survey_points: String?
    @NSManaged public var survey_description: String?
    @NSManaged public var survey_rewards_points: Int32
    @NSManaged public var is_public: Bool
    @NSManaged public var survey_created_at: Date?
    @NSManaged public var survey_updated_at: Date?
    @NSManaged public var survey_status_del: Bool
    @NSManaged public var has_question: Question?
    @NSManaged public var owned_by_user: User?
    @NSManaged public var has_response: HResponse?

}

extension Survey : Identifiable {

}
