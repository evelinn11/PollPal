//
//  DResponse+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias DResponseCoreDataPropertiesSet = NSSet

extension DResponse {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DResponse> {
        return NSFetchRequest<DResponse>(entityName: "DResponse")
    }

    @NSManaged public var dresponse_id: UUID?
    @NSManaged public var dresponse_answer_text: String?
    @NSManaged public var dresponse_status_del: Bool
    @NSManaged public var in_hresponse: HResponse?
    @NSManaged public var has_option: Option?

}

extension DResponse : Identifiable {

}
