//
//  DResponse+CoreDataClass.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData

public typealias DResponseCoreDataClassSet = NSSet

@objc(DResponse)
public class DResponse: NSManagedObject {

}
