//
//  Question+CoreDataClass.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData

public typealias QuestionCoreDataClassSet = NSSet

@objc(Question)
public class Question: NSManagedObject {

}
