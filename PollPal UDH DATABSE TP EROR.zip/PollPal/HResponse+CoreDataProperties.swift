//
//  HResponse+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias HResponseCoreDataPropertiesSet = NSSet

extension HResponse {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<HResponse> {
        return NSFetchRequest<HResponse>(entityName: "HResponse")
    }

    @NSManaged public var hresponse_id: UUID?
    @NSManaged public var submitted_at: Date?
    @NSManaged public var attribute: NSObject?
    @NSManaged public var in_survey: Survey?
    @NSManaged public var in_question: Question?
    @NSManaged public var has_dresponse: DResponse?
    @NSManaged public var is_filled_by_user: User?

}

extension HResponse : Identifiable {

}
