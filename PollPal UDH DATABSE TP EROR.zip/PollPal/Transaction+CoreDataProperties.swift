//
//  Transaction+CoreDataProperties.swift
//  PollPal
//
//  Created by student on 01/12/25.
//
//

public import Foundation
public import CoreData


public typealias TransactionCoreDataPropertiesSet = NSSet

extension Transaction {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Transaction> {
        return NSFetchRequest<Transaction>(entityName: "Transaction")
    }

    @NSManaged public var transaction_id: UUID?
    @NSManaged public var transaction_points_change: Int32
    @NSManaged public var transaction_description: String?
    @NSManaged public var transaction_status_del: Bool
    @NSManaged public var owned_by_user: User?

}

extension Transaction : Identifiable {

}
