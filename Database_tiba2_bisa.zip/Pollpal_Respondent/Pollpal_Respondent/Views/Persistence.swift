import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentCloudKitContainer

    init(inMemory: Bool = false) {
        // ⚠️ PASTIKAN NAMA INI SAMA DENGAN FILE .xcdatamodeld ANDA
        container = NSPersistentCloudKitContainer(name: "PollPal")
        
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Jika error, aplikasi akan crash dan memberitahu alasannya
                fatalError("ERROR LOAD DATABASE: \(error), \(error.userInfo)")
            }
        })
        
        // Agar UI otomatis update
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        // JALANKAN SEEDING
        seedDataIfNeeded(context: container.viewContext)
    }
    
    func seedDataIfNeeded(context: NSManagedObjectContext) {
        // 1. Cek apakah database sudah ada isinya?
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        
        do {
            let count = try context.count(for: fetchRequest)
            if count > 0 {
                print("✅ DATA SUDAH ADA (Skip Seeding).")
                return
            }
        } catch {
            print("❌ Gagal mengecek data: \(error.localizedDescription)")
            return
        }
        
        print("⚡️ DATABASE KOSONG. MEMULAI SEEDING...")
        
        // 2. Buat User: DOSEN (Creator) [cite: 5]
        let dosen = User(context: context)
        dosen.id = UUID()
        dosen.fullName = "Pak Budi Santoso"
        dosen.email = "dosen@uc.ac.id"
        dosen.role = "dosen"
        dosen.pointBalance = 5000 // Modal awal [cite: 1]
        dosen.createdAt = Date()
        
        // 3. Buat User: MAHASISWA (Responden) [cite: 5]
        let mhs = User(context: context)
        mhs.id = UUID()
        mhs.fullName = "Ani Mahasiswi"
        mhs.email = "ani@student.uc.ac.id"
        mhs.role = "mahasiswa"
        mhs.pointBalance = 0 // Awalnya 0 [cite: 1]
        mhs.createdAt = Date()
        
        // 4. Buat Survey Dummy [cite: 27]
        let survey1 = Survey(context: context)
        survey1.id = UUID()
        survey1.title = "Evaluasi Kantin UC"
        survey1.desc = "Survey kepuasan pelanggan kantin lantai 1"
        survey1.rewardPoints = 50
        survey1.isPublic = true
        survey1.createdAt = Date()
        survey1.creator = dosen // Relasi: Milik Pak Budi
        
        // 5. Buat Pertanyaan [cite: 29]
        let q1 = Question(context: context)
        q1.id = UUID()
        q1.text = "Apakah makanan higienis?"
        q1.type = "multiple_choice"
        q1.orderIndex = 1
        q1.survey = survey1 // Relasi: Masuk ke survey1
        
        // 6. Simpan ke Core Data
        do {
            try context.save()
            print("🎉 SEEDING BERHASIL! Data Pak Budi & Ani siap digunakan.")
        } catch {
            print("❌ GAGAL MENYIMPAN DATA: \(error.localizedDescription)")
        }
    }
}
