import SwiftUI
import CoreData

struct SurveyListView: View {
    // 1. FetchRequest: Ambil semua entitas Survey dari Core Data
    @FetchRequest(
        entity: Survey.entity(),
        // Urutkan berdasarkan tanggal dibuat, yang terbaru muncul di atas
        sortDescriptors: [NSSortDescriptor(keyPath: \Survey.createdAt, ascending: false)]
    ) var surveys: FetchedResults<Survey> // Hasil akan disimpan di variabel 'surveys'

    var body: some View {
        NavigationView {
            // 2. Tampilkan daftar Survey
            List {
                if surveys.isEmpty {
                    Text("Belum ada survey yang tersedia.")
                        .foregroundColor(.secondary)
                } else {
                    // Iterasi melalui hasil fetch
                    ForEach(surveys, id: \.self) { survey in
                        // Cek dan pastikan properti yang diperlukan tidak nil
                        let title = survey.title ?? "Survey Tanpa Judul"
                        let desc = survey.desc ?? "Tidak ada deskripsi."
                        
                        // Anda bisa membuat komponen terpisah di sini
                        SurveyRow(surveyTitle: title,
                                  surveyDescription: desc,
                                  rewardPoints: Int(survey.rewardPoints))
                        
                        // Catatan: Jika Anda ingin menavigasi ke detail,
                        // gunakan NavigationLink di sini.
                    }
                }
            }
            .navigationTitle("Daftar Survey Populer")
        }
    }
}

// Komponen kecil untuk menampilkan satu baris survey
struct SurveyRow: View {
    let surveyTitle: String
    let surveyDescription: String
    let rewardPoints: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(surveyTitle)
                .font(.headline)
                .foregroundColor(.primary)
            
            Text(surveyDescription)
                .font(.subheadline)
                .foregroundColor(.gray)
                .lineLimit(2)
            
            HStack {
                Image(systemName: "bolt.fill")
                    .foregroundColor(.yellow)
                Text("\(rewardPoints) Poin Reward")
                    .font(.caption)
                    .fontWeight(.medium)
            }
        }
        .padding(.vertical, 5)
    }
}

