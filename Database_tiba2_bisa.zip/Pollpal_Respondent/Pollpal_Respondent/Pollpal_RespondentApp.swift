//
//  Pollpal_RespondentApp.swift
//  Pollpal_Respondent
//
//  Created by student on 27/11/25.
//
import SwiftUI

@main
struct PollPalApp: App {
    // Inisialisasi Core Data Controller
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                // Menyediakan context Core Data ke environment
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
