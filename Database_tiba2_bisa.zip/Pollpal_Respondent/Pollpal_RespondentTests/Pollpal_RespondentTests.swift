//
//  Pollpal_RespondentTests.swift
//  Pollpal_RespondentTests
//
//  Created by student on 27/11/25.
//

import Testing
@testable import Pollpal_Respondent

struct Pollpal_RespondentTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
