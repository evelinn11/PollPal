import SwiftUI
struct Withdraw: View {
    
    @State private var selectedMethod: String = "OVO"
    
    let points: Int = 50_000
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            
            // MARK: Page Title
            Text("Withdraw Money")
                .font(.system(size: 25, weight: .bold))
                .foregroundColor(.darkTeal)
                .padding(.top, 45)
                .padding(.horizontal)
                .padding(.bottom, 15)
            
            // MARK: Points Card
            VStack(alignment: .center, spacing: 12) {
                
                Text("My Points")
                    .font(.headline)
                    .foregroundColor(.darkTeal)
                
                Text(formatCurrency(points))
                    .font(.system(size: 46, weight: .bold))
                    .foregroundColor(.darkTeal)
                
                Text("You will receive Rp. \(formatCurrency(points)) !")
                    .font(.body)
                    .foregroundColor(.darkTeal)
                
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .cornerRadius(20)
            .shadow(color: .black.opacity(0.1), radius: 10, y: 3)
            .padding(.horizontal)
            
            // MARK: Withdraw To Section
            VStack(alignment: .leading, spacing: 20) {
                
                Text("Withdraw Points To")
                    .font(.title3)
                    .foregroundColor(.darkTeal)
                    .padding(.top, 10)
                    .padding(.bottom,10)
                
                VStack(spacing: 24) {
                    
                    PaymentRow(
                        icon: "gopay",
                        title: "GoPay",
                        method: "GoPay",
                        phone: "08*** **** **21",
                        selectedMethod: $selectedMethod
                    )
                    
                    Divider()
                    
                    PaymentRow(
                        icon: "ovo",
                        title: "OVO",
                        method: "OVO",
                        phone: "08*** **** **21",
                        selectedMethod: $selectedMethod
                    )
                    
                    Divider()
                    
                    PaymentRow(
                        icon: "qris",
                        title: "QRIS",
                        method: "QRIS",
                        phone: "",
                        selectedMethod: $selectedMethod
                    )
                    
                    Divider()
                    
                }
            }
            .padding(.horizontal)
            .padding(.leading, 10)
            
            Spacer()
            
            // MARK: Bottom Button
            VStack {
                Button(action: {}) {
                    Text("Confirm Withdraw")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(Color.darkTeal)
                        .cornerRadius(18)
                }
                .padding(.horizontal)
                .padding(.bottom, 25)
            }
        }
        .padding(.bottom, 30)
        .padding(.horizontal, 10)
        .background(Color(.systemGray6))
        .ignoresSafeArea(edges: .bottom)
    }
}

// MARK: Preview
#Preview {
    Withdraw()
}
