//
//  ContentView.swift
//  PollPal
//
//  Created by student on 27/11/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            NavigationStack{
                DashboardRView()
            }
            .tabItem {
                Image(systemName: "house")
                Text("Home")
            }
            
            NavigationStack{
                    HistoryView()
                    .navigationTitle("History")
            }
            .tabItem{
                Image(systemName: "clock.arrow.trianglehead.counterclockwise.rotate.90")
                Text("History")
            }
            
            NavigationStack{
                ProfileUserView()
            }
            .tabItem{
                Image(systemName: "person")
                Text("Profile")
            }
        }
        .tint(Color(hex: "#FE982A"))
    }
}

#Preview {
    ContentView()
}
