//
//  Survey.swift
//  PollPal
//
//  Created by student on 27/11/25.
//

import Foundation
struct Survey: Identifiable, Codable {
    let survey_id = UUID()
    var survey_title: String = "Untitled Survey"
    var survey_description: String = ""
    var survey_rewards_points: Int = 0
    var is_public: Bool = false
    var survey_created_at = Date()
    var survey_update_at = Date()
    var survey_status_del: Bool = false

    var id: UUID { survey_id }  // <- memberitahu Swift bahwa survey_id adalah id
}
