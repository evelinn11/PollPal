//
//  Question.swift
//  PollPal
//
//  Created by student on 27/11/25.
//

import Foundation

struct Question: Identifiable, Codable {
    let id = UUID()
    var title: String
    var description: String? = ""
    var type: QuestionType
    var options: [String] = []
    var scaleRange: ClosedRange<Int>?
    var answer: AnyCodable?
}
