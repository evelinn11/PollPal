//
//  PollPalTests.swift
//  PollPalTests
//
//  Created by student on 27/11/25.
//

import Testing
@testable import PollPal

struct PollPalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
