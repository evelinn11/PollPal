//
//  NewSurvey2Tests.swift
//  NewSurvey2Tests
//
//  Created by student on 01/12/25.
//

import Testing
@testable import NewSurvey2

struct NewSurvey2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
