//
//  NewSurvey2App.swift
//  NewSurvey2
//
//  Created by student on 01/12/25.
//

import SwiftUI

@main
struct NewSurvey2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
