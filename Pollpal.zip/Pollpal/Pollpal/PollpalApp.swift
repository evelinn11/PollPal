//
//  PollpalApp.swift
//  Pollpal
//
//  Created by student on 20/11/25.
//

import SwiftUI

@main
struct PollpalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
