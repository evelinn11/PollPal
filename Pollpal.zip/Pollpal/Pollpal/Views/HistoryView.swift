//
//  HistoryView.swift
//  Pollpal
//
//  Created by student on 20/11/25.
//

import SwiftUI

struct HistoryView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HistoryView()
}
