//
//  PollpalTests.swift
//  PollpalTests
//
//  Created by student on 20/11/25.
//

import Testing
@testable import Pollpal

struct PollpalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
