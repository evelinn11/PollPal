//
//  Profil_PollPalApp.swift
//  Profil PollPal
//
//  Created by student on 20/11/25.
//

import SwiftUI

@main
struct Profil_PollPalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
