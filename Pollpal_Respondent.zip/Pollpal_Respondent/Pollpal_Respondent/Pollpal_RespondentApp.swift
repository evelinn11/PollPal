//
//  Pollpal_RespondentApp.swift
//  Pollpal_Respondent
//
//  Created by student on 27/11/25.
//

import SwiftUI

@main
struct Pollpal_RespondentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
