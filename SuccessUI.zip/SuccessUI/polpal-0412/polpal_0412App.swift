//
//  polpal_0412App.swift
//  polpal-0412
//
//  Created by student on 04/12/25.
//

import SwiftUI

@main
struct polpal_0412App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
