//
//  polpal_0412Tests.swift
//  polpal-0412Tests
//
//  Created by student on 04/12/25.
//

import Testing
@testable import polpal_0412

struct polpal_0412Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
